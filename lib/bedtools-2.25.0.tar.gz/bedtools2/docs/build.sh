make clean html
open _build/html/index.html -a Chrome
